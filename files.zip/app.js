const { useState, useEffect, useMemo, useRef } = React;
const {
  ResponsiveContainer, LineChart, Line, AreaChart, Area, BarChart, Bar,
  PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  RadarChart, PolarGrid, PolarAngleAxis, Radar
} = Recharts;

/* ============================== ICONS ============================== */
/* Small original line-icon set (no external icon library needed) */
function Icon({ name, className = "w-5 h-5", strokeWidth = 1.8 }) {
  const common = { fill:"none", stroke:"currentColor", strokeWidth, strokeLinecap:"round", strokeLinejoin:"round", viewBox:"0 0 24 24", className };
  const paths = {
    grid: <><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></>,
    camera: <><path d="M4 8h3l1.5-2.2h7L17 8h3a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/><circle cx="12" cy="13" r="3.4"/></>,
    branch: <><circle cx="6" cy="5" r="2"/><circle cx="6" cy="19" r="2"/><circle cx="18" cy="12" r="2"/><path d="M6 7v10M6 12h6a4 4 0 0 0 4-4"/></>,
    trash: <><path d="M4 7h16"/><path d="M9 7V4h6v3"/><path d="M6 7l1 13h10l1-13"/></>,
    recycle: <><path d="M7 8L4.5 12.5 7 17"/><path d="M17 8l2.5 4.5L17 17"/><path d="M9 4h6"/><path d="M7 17h10"/></>,
    chart: <><path d="M4 20V10"/><path d="M11 20V4"/><path d="M18 20v-7"/></>,
    brain: <><path d="M9 4a3 3 0 0 0-3 3v1a3 3 0 0 0-1 5.8V15a3 3 0 0 0 3 3h1"/><path d="M15 4a3 3 0 0 1 3 3v1a3 3 0 0 1 1 5.8V15a3 3 0 0 1-3 3h-1"/><path d="M9 4a3 3 0 0 1 3 3v11a3 3 0 0 1-3 3"/><path d="M15 4a3 3 0 0 0-3 3v11"/></>,
    boxes: <><path d="M3 8l5-3 5 3v6l-5 3-5-3z"/><path d="M13 8l4-2.4 4 2.4v5.4l-4 2.4"/><path d="M8 5v6M17 5.6v5.4"/></>,
    sliders: <><path d="M4 6h10M17 6h3"/><path d="M4 12h4M11 12h9"/><path d="M4 18h13M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="8" cy="12" r="2"/><circle cx="17" cy="18" r="2"/></>,
    bell: <><path d="M6 10a6 6 0 0 1 12 0c0 4 1.4 5.4 1.4 5.4H4.6S6 14 6 10z"/><path d="M10 18a2 2 0 0 0 4 0"/></>,
    file: <><path d="M7 3h7l4 4v14H7z"/><path d="M14 3v4h4"/><path d="M9.5 13h5M9.5 16.5h5"/></>,
    info: <><circle cx="12" cy="12" r="9"/><path d="M12 11v5.5"/><circle cx="12" cy="7.6" r="0.15" strokeWidth="3"/></>,
    settings: <><circle cx="12" cy="12" r="3"/><path d="M19.4 13a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V19a2 2 0 1 1-4 0v-.2a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H4a2 2 0 1 1 0-4h.2a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H10a1.7 1.7 0 0 0 1-1.5V4a2 2 0 1 1 4 0v.2a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V10a1.7 1.7 0 0 0 1.5 1H20a2 2 0 1 1 0 4h-.2a1.7 1.7 0 0 0-1.4 1z"/></>,
    dollar: <><path d="M12 3v18"/><path d="M16.5 7.5c0-1.7-2-3-4.5-3s-4.5 1.2-4.5 3 2 2.6 4.5 3 4.5 1.3 4.5 3-2 3-4.5 3-4.5-1.3-4.5-3"/></>,
    check: <path d="M4 12.5l5 5L20 6.5"/>,
    arrowRight: <><path d="M4 12h16"/><path d="M13 5l7 7-7 7"/></>,
    leaf: <><path d="M20 4S8 4 6 12s2 8 2 8 12 0 12-16z"/><path d="M8 20C10 12 20 4 20 4"/></>,
    sun: <><circle cx="12" cy="12" r="4"/><path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"/></>,
    wifi: <><path d="M2 8.5a16 16 0 0 1 20 0"/><path d="M5.5 12.5a11 11 0 0 1 13 0"/><path d="M9 16.5a5.6 5.6 0 0 1 6 0"/><circle cx="12" cy="19.4" r="0.2" strokeWidth="3"/></>,
    menu: <><path d="M4 7h16M4 12h16M4 17h16"/></>,
    x: <><path d="M5 5l14 14M19 5L5 19"/></>,
    zap: <path d="M13 3L5 14h6l-1 7 8-11h-6z"/>,
    trend: <><path d="M4 15l5-6 4 3 7-8"/><path d="M15 4h5v5"/></>,
    shield: <path d="M12 3l7 3v6c0 5-3.5 7.6-7 9-3.5-1.4-7-4-7-9V6z"/>,
    droplet: <path d="M12 3s6 6.5 6 10.5a6 6 0 1 1-12 0C6 9.5 12 3 12 3z"/>,
    truck: <><path d="M2 8h11v8H2z"/><path d="M13 11h4l3 3v2h-7z"/><circle cx="6" cy="18" r="1.6"/><circle cx="17" cy="18" r="1.6"/></>,
    globe: <><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.6 3.8 5.8 3.8 9s-1.3 6.4-3.8 9c-2.5-2.6-3.8-5.8-3.8-9S9.5 5.6 12 3z"/></>,
    layers: <><path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/></>,
  };
  return <svg {...common}>{paths[name] || paths.grid}</svg>;
}

/* ============================== MOCK DATA ============================== */
const CATS = [
  { key:"plastic", label:"Plastic", color:"#177450" },
  { key:"paper", label:"Paper / Cardboard", color:"#8fd63a" },
  { key:"metal", label:"Metal", color:"#5b7a8c" },
  { key:"glass", label:"Glass", color:"#3fa9a0" },
  { key:"organic", label:"Organic", color:"#c99a3e" },
  { key:"ewaste", label:"E-Waste", color:"#a15bd6" },
  { key:"reject", label:"Reject / Unknown", color:"#8a8f86" },
];
function seededRand(seed){ let s = seed; return () => { s = (s*9301+49297)%233280; return s/233280; }; }
const rnd = seededRand(42);
const between = (a,b) => Math.round((a + rnd()*(b-a))*10)/10;

const hourly = Array.from({length:24}, (_,h) => ({
  hour: `${String(h).padStart(2,"0")}:00`,
  kg: Math.round(28 + Math.sin(h/2.4)*16 + rnd()*10 + (h>8&&h<19?18:0)),
}));
const categoryDist = CATS.map(c => ({ name:c.label, value: Math.round(80+rnd()*220), color:c.color }));
const recoveryTrend = Array.from({length:7}, (_,i)=>({ day:["Mon","Tue","Wed","Thu","Fri","Sat","Sun"][i], rate: Math.round(74+rnd()*16) }));
const accuracyTrend = Array.from({length:7}, (_,i)=>({ day:["Mon","Tue","Wed","Thu","Fri","Sat","Sun"][i], accuracy: Math.round(90+rnd()*7) }));
const dailyRecovery = Array.from({length:7}, (_,i)=>({
  day:["Mon","Tue","Wed","Thu","Fri","Sat","Sun"][i],
  plastic: Math.round(30+rnd()*40), paper: Math.round(25+rnd()*35), metal: Math.round(10+rnd()*15),
  glass: Math.round(8+rnd()*12), organic: Math.round(20+rnd()*30),
}));
const binsData = [
  { name:"Plastic", key:"plastic", fill:62, capacityKg:120, status:"Normal" },
  { name:"Paper / Cardboard", key:"paper", fill:44, capacityKg:150, status:"Normal" },
  { name:"Metal", key:"metal", fill:81, capacityKg:90, status:"Near Full" },
  { name:"Glass", key:"glass", fill:35, capacityKg:100, status:"Normal" },
  { name:"Organic", key:"organic", fill:58, capacityKg:110, status:"Normal" },
  { name:"E-Waste", key:"ewaste", fill:22, capacityKg:60, status:"Normal" },
  { name:"Reject / Unknown", key:"reject", fill:12, capacityKg:70, status:"Normal" },
];
const alertsData = [
  { level:"warning", title:"Metal bin approaching capacity", detail:"Bin at 81% — collection recommended within 6 hours.", time:"12 min ago" },
  { level:"info", title:"Model confidence dip on wet cardboard", detail:"Classification confidence dropped to 88% during rain event. Verification sensors compensated.", time:"1 hr ago" },
  { level:"success", title:"Daily recovery target reached", detail:"82.4% recovery rate achieved for the current cycle.", time:"3 hr ago" },
  { level:"warning", title:"Conveyor belt vibration anomaly", detail:"Sensor #4 recorded vibration above baseline for 40s. Auto-diagnostic passed.", time:"5 hr ago" },
  { level:"info", title:"Scheduled maintenance window", detail:"Predictive maintenance suggests inspection of sorting arm actuator in ~9 days.", time:"1 day ago" },
];
const detectionLog = [
  { id:1, object:"PET Bottle", material:"Plastic", confidence:94.2 },
  { id:2, object:"Corrugated Box", material:"Paper / Cardboard", confidence:97.1 },
  { id:3, object:"Aluminium Can", material:"Metal", confidence:91.6 },
  { id:4, object:"Glass Jar", material:"Glass", confidence:88.9 },
  { id:5, object:"Banana Peel", material:"Organic", confidence:96.4 },
  { id:6, object:"Circuit Board", material:"E-Waste", confidence:83.2 },
];

function StatCard({ icon, label, value, sub, tone="forest" }) {
  const tones = { forest:"text-forest-700 bg-forest-700/10", lime:"text-lime-600 bg-lime-500/15", navy:"text-navy-800 bg-navy-800/10" };
  return (
    <div className="bg-white rounded-2xl border border-navy-900/5 shadow-sm p-5 fade-up">
      <div className="flex items-center justify-between mb-3">
        <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${tones[tone]}`}><Icon name={icon} className="w-4.5 h-4.5" /></div>
      </div>
      <div className="font-mono text-2xl font-semibold tracking-tight text-navy-900">{value}</div>
      <div className="text-xs text-navy-900/50 mt-1">{label}</div>
      {sub && <div className="text-[11px] mt-2 text-forest-700 font-medium">{sub}</div>}
    </div>
  );
}
function Card({ title, subtitle, right, children, className="" }) {
  return (
    <div className={`bg-white rounded-2xl border border-navy-900/5 shadow-sm p-5 ${className}`}>
      {(title || right) && (
        <div className="flex items-start justify-between mb-4">
          <div>
            {title && <h3 className="font-display font-semibold text-navy-900 text-sm">{title}</h3>}
            {subtitle && <p className="text-xs text-navy-900/45 mt-0.5">{subtitle}</p>}
          </div>
          {right}
        </div>
      )}
      {children}
    </div>
  );
}
function DemoBadge({ label="Demo Mode — Simulated Data" }) {
  return (
    <div className="inline-flex items-center gap-1.5 text-[11px] font-medium px-2.5 py-1 rounded-full bg-lime-500/15 text-forest-700 border border-lime-500/30">
      <span className="w-1.5 h-1.5 rounded-full bg-lime-500 pulse-dot"></span>{label}
    </div>
  );
}
function PageHeader({ eyebrow, title, desc, right }) {
  return (
    <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
      <div>
        {eyebrow && <div className="text-[11px] uppercase tracking-widest text-forest-700 font-semibold mb-1">{eyebrow}</div>}
        <h1 className="font-display text-2xl md:text-3xl font-semibold text-navy-900">{title}</h1>
        {desc && <p className="text-sm text-navy-900/50 mt-1 max-w-2xl">{desc}</p>}
      </div>
      {right}
    </div>
  );
}

/* ============================== DASHBOARD PAGES ============================== */
function DashboardHome() {
  return (
    <div>
      <PageHeader eyebrow="Command Center" title="EcoSort AI Command Center" desc="Real-time overview of sorting throughput, recovery performance and machine health." right={<DemoBadge/>} />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <StatCard icon="layers" label="Total Waste Processed" value="1,284 kg" sub="+6.2% vs yesterday" />
        <StatCard icon="recycle" label="Recyclable Waste" value="864 kg" sub="67.3% of total" tone="lime"/>
        <StatCard icon="trend" label="Recovery Rate" value="82.4%" sub="Target: 80%" />
        <StatCard icon="shield" label="Sorting Accuracy" value="94.7%" sub="Last 24h average" tone="navy"/>
        <StatCard icon="truck" label="Landfill Diversion" value="1,056 kg" sub="82.3% diverted" />
        <StatCard icon="dollar" label="Est. Resource Value" value="₹24,850" sub="At current market rates" tone="lime"/>
        <StatCard icon="leaf" label="CO₂ Impact Avoided" value="642 kg CO₂e" sub="Equivalent to 29 trees/yr" />
        <StatCard icon="zap" label="Machine Status" value="ONLINE" sub="Uptime 99.2% (7d)" tone="navy"/>
      </div>

      <div className="grid lg:grid-cols-3 gap-5 mb-5">
        <Card title="Waste Processed — Last 24 Hours" subtitle="Kilograms processed per hour" className="lg:col-span-2">
          <ResponsiveContainer width="100%" height={230}>
            <AreaChart data={hourly}>
              <defs><linearGradient id="gArea" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#177450" stopOpacity={0.35}/><stop offset="100%" stopColor="#177450" stopOpacity={0}/></linearGradient></defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#eef1e9"/>
              <XAxis dataKey="hour" interval={3} tick={{fontSize:11}} stroke="#8a9186"/>
              <YAxis tick={{fontSize:11}} stroke="#8a9186"/>
              <Tooltip contentStyle={{borderRadius:12, fontSize:12, border:"1px solid #eef1e9"}}/>
              <Area type="monotone" dataKey="kg" stroke="#177450" strokeWidth={2} fill="url(#gArea)" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>
        <Card title="Waste Category Distribution" subtitle="Cumulative today (kg)">
          <ResponsiveContainer width="100%" height={230}>
            <PieChart>
              <Pie data={categoryDist} dataKey="value" nameKey="name" innerRadius={48} outerRadius={80} paddingAngle={2}>
                {categoryDist.map((c,i)=><Cell key={i} fill={c.color}/>)}
              </Pie>
              <Tooltip contentStyle={{borderRadius:12, fontSize:12}}/>
            </PieChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-2 gap-x-2 gap-y-1 mt-2">
            {categoryDist.map((c,i)=>(
              <div key={i} className="flex items-center gap-1.5 text-[11px] text-navy-900/60">
                <span className="w-2 h-2 rounded-full" style={{background:c.color}}></span>{c.name}
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-5">
        <Card title="Recovery Rate Trend" subtitle="7-day rolling %">
          <ResponsiveContainer width="100%" height={190}>
            <LineChart data={recoveryTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#eef1e9"/>
              <XAxis dataKey="day" tick={{fontSize:11}} stroke="#8a9186"/><YAxis tick={{fontSize:11}} stroke="#8a9186"/>
              <Tooltip contentStyle={{borderRadius:12, fontSize:12}}/>
              <Line type="monotone" dataKey="rate" stroke="#8fd63a" strokeWidth={3} dot={{r:3}}/>
            </LineChart>
          </ResponsiveContainer>
        </Card>
        <Card title="Sorting Accuracy Trend" subtitle="7-day rolling %">
          <ResponsiveContainer width="100%" height={190}>
            <LineChart data={accuracyTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#eef1e9"/>
              <XAxis dataKey="day" tick={{fontSize:11}} stroke="#8a9186"/><YAxis domain={[80,100]} tick={{fontSize:11}} stroke="#8a9186"/>
              <Tooltip contentStyle={{borderRadius:12, fontSize:12}}/>
              <Line type="monotone" dataKey="accuracy" stroke="#0e4633" strokeWidth={3} dot={{r:3}}/>
            </LineChart>
          </ResponsiveContainer>
        </Card>
        <Card title="Daily Material Recovery" subtitle="Stacked by category (kg)">
          <ResponsiveContainer width="100%" height={190}>
            <BarChart data={dailyRecovery}>
              <CartesianGrid strokeDasharray="3 3" stroke="#eef1e9"/>
              <XAxis dataKey="day" tick={{fontSize:11}} stroke="#8a9186"/><YAxis tick={{fontSize:11}} stroke="#8a9186"/>
              <Tooltip contentStyle={{borderRadius:12, fontSize:12}}/>
              <Bar dataKey="plastic" stackId="a" fill="#177450"/><Bar dataKey="paper" stackId="a" fill="#8fd63a"/>
              <Bar dataKey="metal" stackId="a" fill="#5b7a8c"/><Bar dataKey="glass" stackId="a" fill="#3fa9a0"/><Bar dataKey="organic" stackId="a" fill="#c99a3e"/>
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>
    </div>
  );
}

function AIDetectionPage() {
  const [mode, setMode] = useState("upload");
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState(null);

  const runDetection = () => {
    setScanning(true); setResult(null);
    setTimeout(()=>{
      const pick = detectionLog[Math.floor(rnd()*detectionLog.length)];
      const rest = 100 - pick.confidence;
      setResult({
        object: pick.object, material: pick.material, confidence: pick.confidence,
        secondary: [
          { label: CATS[(CATS.findIndex(c=>c.label===pick.material)+1)%7].label, v: Math.round(rest*0.5*10)/10 },
          { label: CATS[(CATS.findIndex(c=>c.label===pick.material)+2)%7].label, v: Math.round(rest*0.3*10)/10 },
          { label: "Other", v: Math.round(rest*0.2*10)/10 },
        ]
      });
      setScanning(false);
    }, 1400);
  };

  return (
    <div>
      <PageHeader eyebrow="Computer Vision" title="AI Waste Detection" desc="Simulated inference pipeline — swap in a live YOLO / TFLite / OpenCV backend without changing this interface." right={<DemoBadge/>} />
      <div className="flex gap-2 mb-5">
        <button onClick={()=>setMode("upload")} className={`px-4 py-2 rounded-xl text-sm font-medium border transition ${mode==="upload"?"bg-forest-700 text-white border-forest-700":"bg-white text-navy-900/60 border-navy-900/10"}`}>Upload Image</button>
        <button onClick={()=>setMode("camera")} className={`px-4 py-2 rounded-xl text-sm font-medium border transition ${mode==="camera"?"bg-forest-700 text-white border-forest-700":"bg-white text-navy-900/60 border-navy-900/10"}`}>Demo Camera</button>
      </div>
      <div className="grid lg:grid-cols-2 gap-5">
        <Card title={mode==="upload" ? "Upload Image" : "Live Demo Camera Feed"} subtitle={mode==="upload" ? "Drop or select a waste item photo" : "Simulated conveyor-mounted camera frame"}>
          <div className="aspect-video rounded-xl bg-navy-950 relative overflow-hidden flex items-center justify-center border border-navy-900/10">
            <div className="absolute inset-0 opacity-40" style={{backgroundImage:"linear-gradient(#177450 1px, transparent 1px), linear-gradient(90deg, #177450 1px, transparent 1px)", backgroundSize:"26px 26px"}}></div>
            {scanning && <div className="absolute left-0 right-0 h-0.5 bg-lime-400 shadow-[0_0_16px_4px_rgba(167,230,79,0.6)]" style={{animation:"scanline 1.4s linear infinite"}}></div>}
            <style>{`@keyframes scanline{0%{top:4%}100%{top:96%}}`}</style>
            <div className="relative z-10 text-center px-6">
              <Icon name="camera" className="w-9 h-9 text-lime-400 mx-auto mb-2"/>
              <p className="text-white/70 text-xs">{mode==="upload" ? "No file selected — click Run Detection to simulate an upload" : "Camera stream simulated for hackathon demo"}</p>
            </div>
          </div>
          <button onClick={runDetection} disabled={scanning} className="mt-4 w-full bg-forest-700 hover:bg-forest-800 disabled:opacity-60 text-white text-sm font-medium py-2.5 rounded-xl transition flex items-center justify-center gap-2">
            {scanning ? "Analyzing frame…" : "Run Detection"} {!scanning && <Icon name="zap" className="w-4 h-4"/>}
          </button>
        </Card>

        <Card title="Detection Result" subtitle="AI classification + sensor verification">
          {!result && !scanning && <div className="h-full min-h-[220px] flex flex-col items-center justify-center text-center text-navy-900/40 text-sm"><Icon name="brain" className="w-8 h-8 mb-2 opacity-50"/>Run a detection to see AI output</div>}
          {scanning && <div className="h-full min-h-[220px] flex flex-col items-center justify-center text-center text-navy-900/40 text-sm">Running inference…</div>}
          {result && (
            <div className="fade-up">
              <div className="flex items-center justify-between border-b border-navy-900/5 pb-3 mb-3">
                <div><div className="text-xs text-navy-900/40">Detected Object</div><div className="font-display font-semibold text-lg">{result.object}</div></div>
                <div className="text-right"><div className="text-xs text-navy-900/40">Classification</div><div className="font-medium text-forest-700">{result.material}</div></div>
              </div>
              <div className="mb-4">
                <div className="flex justify-between text-xs mb-1"><span className="text-navy-900/50">Confidence</span><span className="font-mono font-semibold">{result.confidence}%</span></div>
                <div className="h-2 rounded-full bg-navy-900/5 overflow-hidden"><div className="h-full bg-lime-500 rounded-full" style={{width:`${result.confidence}%`}}></div></div>
              </div>
              <div className="text-xs text-navy-900/40 mb-2">Secondary predictions</div>
              <div className="space-y-2">
                {result.secondary.map((s,i)=>(
                  <div key={i} className="flex items-center gap-2 text-xs">
                    <span className="w-28 truncate text-navy-900/60">{s.label}</span>
                    <div className="flex-1 h-1.5 bg-navy-900/5 rounded-full overflow-hidden"><div className="h-full bg-navy-800/40 rounded-full" style={{width:`${Math.min(100,s.v*4)}%`}}></div></div>
                    <span className="font-mono w-10 text-right">{s.v}%</span>
                  </div>
                ))}
              </div>
              <div className="mt-4 flex items-center gap-2 text-xs bg-forest-700/5 text-forest-700 rounded-lg px-3 py-2">
                <Icon name="check" className="w-4 h-4"/> Sensor verification passed — routed to {result.material} bin.
              </div>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

function SortingMonitorPage(){
  const stages = [
    {name:"Infeed", icon:"layers"}, {name:"Camera + Sensors", icon:"camera"}, {name:"AI Classification", icon:"brain"},
    {name:"Sensor Verification", icon:"shield"}, {name:"Decision Engine", icon:"branch"}, {name:"Sorting Arm", icon:"zap"}, {name:"Material Bin", icon:"trash"}
  ];
  const [active,setActive]=useState(2);
  useEffect(()=>{ const t=setInterval(()=>setActive(a=>(a+1)%stages.length), 1600); return ()=>clearInterval(t); },[]);
  return (
    <div>
      <PageHeader eyebrow="Live Operations" title="Sorting Monitor" desc="End-to-end pipeline visualization of the physical sorting line." right={<DemoBadge/>} />
      <Card className="mb-5">
        <div className="flex items-center overflow-x-auto pb-2">
          {stages.map((s,i)=>(
            <React.Fragment key={i}>
              <div className={`flex flex-col items-center gap-2 min-w-[92px] transition ${i===active?"scale-105":""}`}>
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border-2 transition ${i===active?"bg-forest-700 border-forest-700 text-white":"bg-white border-navy-900/10 text-navy-900/40"}`}><Icon name={s.icon} className="w-5 h-5"/></div>
                <span className={`text-[11px] text-center ${i===active?"text-forest-700 font-semibold":"text-navy-900/40"}`}>{s.name}</span>
              </div>
              {i<stages.length-1 && <div className={`h-0.5 flex-1 min-w-[24px] mx-1 ${i<active?"bg-forest-700":"bg-navy-900/10"}`}></div>}
            </React.Fragment>
          ))}
        </div>
      </Card>
      <div className="grid lg:grid-cols-3 gap-5">
        <Card title="Conveyor Feed" subtitle="Simulated item flow" className="lg:col-span-2">
          <div className="relative h-40 rounded-xl overflow-hidden belt border border-navy-900/10">
            {[0,1,2,3,4].map(i=>(
              <div key={i} className="item-anim absolute top-1/2 -translate-y-1/2 w-8 h-8 rounded-md shadow-lg" style={{ background: CATS[i%CATS.length].color, animationDuration: `${6+i}s`, animationDelay:`${i*1.3}s` }}></div>
            ))}
          </div>
          <div className="grid grid-cols-3 gap-3 mt-4 text-center">
            <div><div className="font-mono text-xl font-semibold">2.4 m/s</div><div className="text-[11px] text-navy-900/40">Belt speed</div></div>
            <div><div className="font-mono text-xl font-semibold">38/min</div><div className="text-[11px] text-navy-900/40">Items processed</div></div>
            <div><div className="font-mono text-xl font-semibold">210ms</div><div className="text-[11px] text-navy-900/40">Avg inference time</div></div>
          </div>
        </Card>
        <Card title="Sorting Arm Status" subtitle="Actuator diagnostics">
          <div className="space-y-3">
            {[["Arm 1 — Plastic","Operational",96],["Arm 2 — Metal","Operational",99],["Arm 3 — Organic","Operational",92],["Arm 4 — Reject Gate","Operational",100]].map((a,i)=>(
              <div key={i}>
                <div className="flex justify-between text-xs mb-1"><span className="text-navy-900/60">{a[0]}</span><span className="text-forest-700 font-medium">{a[1]}</span></div>
                <div className="h-1.5 rounded-full bg-navy-900/5 overflow-hidden"><div className="h-full bg-forest-700 rounded-full" style={{width:`${a[2]}%`}}></div></div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

function SmartBinsPage(){
  return (
    <div>
      <PageHeader eyebrow="Fleet" title="Smart Bins" desc="Fill-level, capacity and collection status across all material bins." right={<DemoBadge/>} />
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {binsData.map((b,i)=>(
          <Card key={i} title={b.name} subtitle={`Capacity ${b.capacityKg} kg`} right={<span className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${b.status==="Near Full"?"bg-amber-500/15 text-amber-700":"bg-forest-700/10 text-forest-700"}`}>{b.status}</span>}>
            <div className="flex items-end gap-4">
              <div className="relative w-16 h-28 rounded-b-xl rounded-t-md border-2 border-navy-900/15 overflow-hidden flex items-end bg-navy-900/[0.02]">
                <div className="w-full transition-all" style={{height:`${b.fill}%`, background: CATS.find(c=>c.key===b.key)?.color || "#177450"}}></div>
              </div>
              <div>
                <div className="font-mono text-2xl font-semibold">{b.fill}%</div>
                <div className="text-[11px] text-navy-900/40 mb-2">current fill level</div>
                <div className="text-[11px] text-navy-900/50">Est. {Math.round(b.capacityKg*b.fill/100)} kg / {b.capacityKg} kg</div>
                <div className="text-[11px] text-navy-900/50">Next pickup: {b.fill>75? "Today" : "In 2–3 days"}</div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

function ResourceRecoveryPage(){
  const value = [
    { name:"Plastic", kg:312, rate:22, key:"plastic" }, { name:"Paper / Cardboard", kg:268, rate:9, key:"paper" },
    { name:"Metal", kg:96, rate:145, key:"metal" }, { name:"Glass", kg:74, rate:6, key:"glass" },
    { name:"E-Waste", kg:31, rate:410, key:"ewaste" },
  ];
  const total = value.reduce((s,v)=>s+v.kg*v.rate,0);
  return (
    <div>
      <PageHeader eyebrow="Circular Economy" title="Resource Recovery" desc="Recovered material value based on current indicative market rates." right={<DemoBadge/>} />
      <div className="grid md:grid-cols-3 gap-4 mb-5">
        <StatCard icon="dollar" label="Total Recovered Value (Today)" value={`₹${total.toLocaleString("en-IN")}`} tone="lime"/>
        <StatCard icon="recycle" label="Material Recovered" value="781 kg" sub="60.8% of processed waste"/>
        <StatCard icon="leaf" label="Landfill Avoided" value="1,056 kg" sub="Cumulative today"/>
      </div>
      <Card title="Recovery Value by Material" subtitle="Indicative ₹/kg rates — demo pricing">
        <div className="space-y-4">
          {value.map((v,i)=>(
            <div key={i} className="flex items-center gap-4">
              <div className="w-36 text-sm font-medium text-navy-900/70">{v.name}</div>
              <div className="flex-1 h-2.5 rounded-full bg-navy-900/5 overflow-hidden"><div className="h-full rounded-full" style={{width:`${Math.min(100,(v.kg*v.rate)/total*100*3)}%`, background: CATS.find(c=>c.key===v.key)?.color}}></div></div>
              <div className="w-28 text-right font-mono text-sm">₹{(v.kg*v.rate).toLocaleString("en-IN")}</div>
              <div className="w-24 text-right text-xs text-navy-900/40">{v.kg}kg × ₹{v.rate}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function AnalyticsPage(){
  const radar = [
    { metric:"Accuracy", v:95 }, { metric:"Speed", v:82 }, { metric:"Uptime", v:99 },
    { metric:"Recovery", v:82 }, { metric:"Contamination", v:74 }, { metric:"Energy Eff.", v:88 },
  ];
  return (
    <div>
      <PageHeader eyebrow="Insights" title="Analytics" desc="Deeper performance analysis across accuracy, contamination and throughput." right={<DemoBadge/>} />
      <div className="grid lg:grid-cols-2 gap-5 mb-5">
        <Card title="System Performance Radar" subtitle="Composite score out of 100">
          <ResponsiveContainer width="100%" height={260}>
            <RadarChart data={radar} outerRadius={90}>
              <PolarGrid stroke="#eef1e9"/><PolarAngleAxis dataKey="metric" tick={{fontSize:11}}/>
              <Radar dataKey="v" stroke="#177450" fill="#177450" fillOpacity={0.35}/>
            </RadarChart>
          </ResponsiveContainer>
        </Card>
        <Card title="Weekly Throughput vs Recovery" subtitle="kg processed vs recovery %">
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={recoveryTrend.map((r,i)=>({ day:r.day, throughput: 900+Math.round(rnd()*400), rate:r.rate }))}>
              <CartesianGrid strokeDasharray="3 3" stroke="#eef1e9"/>
              <XAxis dataKey="day" tick={{fontSize:11}}/><YAxis tick={{fontSize:11}}/>
              <Tooltip contentStyle={{borderRadius:12, fontSize:12}}/>
              <Bar dataKey="throughput" fill="#0e4633" radius={[6,6,0,0]}/>
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>
      <Card title="Contamination Analysis" subtitle="Misclassification causes (demo sample, last 500 items)">
        <div className="grid sm:grid-cols-2 gap-4">
          {[["Wet / soiled surface",34],["Mixed-material item",27],["Poor lighting angle",18],["Occlusion on belt",13],["Sensor noise",8]].map((c,i)=>(
            <div key={i} className="flex items-center gap-3">
              <span className="w-40 text-sm text-navy-900/60">{c[0]}</span>
              <div className="flex-1 h-2 bg-navy-900/5 rounded-full overflow-hidden"><div className="h-full bg-lime-500 rounded-full" style={{width:`${c[1]*2.6}%`}}></div></div>
              <span className="font-mono text-xs w-8 text-right">{c[1]}%</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function RecommendationsPage(){
  const recs = [
    { title:"Increase reject-gate threshold by 4%", impact:"+1.8% recovery rate", conf:88, desc:"Model shows conservative rejection on ambiguous plastics; a small threshold change recovers items without raising contamination." },
    { title:"Schedule metal bin pickup earlier", impact:"Avoids overflow risk", conf:95, desc:"Fill trend suggests metal bin crosses 95% within 5 hours at current throughput." },
    { title:"Add secondary lighting at infeed", impact:"+2.3% accuracy (est.)", conf:76, desc:"Low-confidence detections cluster during 6–8 PM when ambient light drops." },
    { title:"Route E-waste to weekly bulk collection", impact:"Lower logistics cost", conf:81, desc:"Current volume doesn't justify daily E-waste pickups; batching reduces trips by ~40%." },
  ];
  return (
    <div>
      <PageHeader eyebrow="Decision Support" title="AI Recommendations" desc="Model-generated operational suggestions based on simulated historical patterns." right={<DemoBadge/>} />
      <div className="grid md:grid-cols-2 gap-5">
        {recs.map((r,i)=>(
          <Card key={i}>
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-lime-500/15 text-forest-700 flex items-center justify-center shrink-0"><Icon name="brain" className="w-5 h-5"/></div>
              <div className="flex-1">
                <div className="flex items-center justify-between gap-2">
                  <h4 className="font-display font-semibold text-sm">{r.title}</h4>
                  <span className="text-[11px] font-mono text-navy-900/40 shrink-0">{r.conf}% conf.</span>
                </div>
                <p className="text-xs text-navy-900/50 mt-1.5">{r.desc}</p>
                <div className="mt-2 text-[11px] font-medium text-forest-700 bg-forest-700/5 inline-block px-2 py-1 rounded-lg">{r.impact}</div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

function DigitalTwinPage(){
  return (
    <div>
      <PageHeader eyebrow="Simulation" title="Digital Factory / Digital Twin" desc="Live conceptual twin of the physical sorting facility for remote monitoring." right={<DemoBadge/>} />
      <Card>
        <div className="grid md:grid-cols-4 gap-4">
          <div className="md:col-span-3 aspect-[16/9] rounded-xl bg-navy-950 relative overflow-hidden border border-navy-900/10">
            <div className="absolute inset-0" style={{backgroundImage:"linear-gradient(rgba(23,116,80,.25) 1px, transparent 1px), linear-gradient(90deg, rgba(23,116,80,.25) 1px, transparent 1px)", backgroundSize:"22px 22px"}}></div>
            {binsData.slice(0,6).map((b,i)=>(
              <div key={i} className="absolute w-12 h-12 rounded-lg border-2 flex items-center justify-center text-[9px] text-white/80 font-mono"
                style={{ left:`${10+i*15}%`, top:`${30+(i%2)*30}%`, borderColor: CATS.find(c=>c.key===b.key)?.color, background:`${CATS.find(c=>c.key===b.key)?.color}22` }}>
                {b.fill}%
              </div>
            ))}
            <div className="absolute bottom-3 left-3 text-[11px] text-lime-400/80 font-mono">TWIN SYNC: LIVE (simulated)</div>
          </div>
          <div className="space-y-3">
            {["Infeed Sensor Array","Vision Module A/B","Sorting Arm Cluster","Bin Weight Sensors","Solar Inverter"].map((s,i)=>(
              <div key={i} className="flex items-center justify-between text-xs bg-navy-900/[0.03] rounded-lg px-3 py-2">
                <span className="text-navy-900/60">{s}</span>
                <span className="flex items-center gap-1.5 text-forest-700 font-medium"><span className="w-1.5 h-1.5 rounded-full bg-forest-700"></span>OK</span>
              </div>
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
}

function SimulatorPage(){
  const [throughput,setThroughput]=useState(50);
  const [contamination,setContamination]=useState(15);
  const [staffing,setStaffing]=useState(2);
  const recovery = Math.max(40, Math.min(96, 78 + (throughput-50)*0.15 - contamination*0.6 + staffing*1.2)).toFixed(1);
  const accuracy = Math.max(70, Math.min(99, 92 - contamination*0.35 + staffing*0.6)).toFixed(1);
  const cost = Math.round(12000 + staffing*4200 + throughput*38);
  return (
    <div>
      <PageHeader eyebrow="Scenario Planning" title="What-If Simulator" desc="Adjust operating parameters to see projected impact on recovery, accuracy and cost." right={<DemoBadge/>} />
      <div className="grid lg:grid-cols-2 gap-5">
        <Card title="Parameters">
          {[
            { label:"Daily Throughput (bags/hr)", val:throughput, set:setThroughput, min:10, max:100, unit:"" },
            { label:"Input Contamination Level", val:contamination, set:setContamination, min:0, max:50, unit:"%" },
            { label:"On-site Staffing", val:staffing, set:setStaffing, min:0, max:6, unit:" people" },
          ].map((p,i)=>(
            <div key={i} className="mb-6 last:mb-0">
              <div className="flex justify-between text-xs mb-2"><span className="text-navy-900/60">{p.label}</span><span className="font-mono font-semibold">{p.val}{p.unit}</span></div>
              <input type="range" min={p.min} max={p.max} value={p.val} onChange={e=>p.set(Number(e.target.value))} className="w-full accent-forest-700"/>
            </div>
          ))}
        </Card>
        <Card title="Projected Outcome" subtitle="Recalculated instantly from a simplified demo model">
          <div className="grid grid-cols-3 gap-3 mb-4">
            <div className="bg-forest-700/5 rounded-xl p-4 text-center"><div className="font-mono text-2xl font-semibold text-forest-700">{recovery}%</div><div className="text-[11px] text-navy-900/40 mt-1">Recovery rate</div></div>
            <div className="bg-lime-500/10 rounded-xl p-4 text-center"><div className="font-mono text-2xl font-semibold text-forest-700">{accuracy}%</div><div className="text-[11px] text-navy-900/40 mt-1">Sorting accuracy</div></div>
            <div className="bg-navy-900/5 rounded-xl p-4 text-center"><div className="font-mono text-2xl font-semibold text-navy-900">₹{cost.toLocaleString("en-IN")}</div><div className="text-[11px] text-navy-900/40 mt-1">Daily op. cost</div></div>
          </div>
          <p className="text-xs text-navy-900/45 leading-relaxed">This projection uses a simplified illustrative formula for demonstration purposes only. In production, this panel would call a calibrated simulation model trained on historical operating data.</p>
        </Card>
      </div>
    </div>
  );
}

function AlertsPage(){
  const styles = { warning:"bg-amber-500/10 text-amber-700 border-amber-500/20", info:"bg-navy-800/5 text-navy-800 border-navy-800/10", success:"bg-forest-700/10 text-forest-700 border-forest-700/20" };
  const icons = { warning:"bell", info:"info", success:"check" };
  return (
    <div>
      <PageHeader eyebrow="Notifications" title="Alerts" desc="System, maintenance and performance alerts across the facility." right={<DemoBadge/>} />
      <div className="space-y-3">
        {alertsData.map((a,i)=>(
          <div key={i} className={`flex items-start gap-3 rounded-2xl border p-4 bg-white ${styles[a.level].split(" ").filter(c=>c.startsWith("border")).join(" ")}`}>
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${styles[a.level]}`}><Icon name={icons[a.level]} className="w-4.5 h-4.5"/></div>
            <div className="flex-1">
              <div className="flex items-center justify-between gap-2">
                <h4 className="font-medium text-sm text-navy-900">{a.title}</h4>
                <span className="text-[11px] text-navy-900/35 shrink-0">{a.time}</span>
              </div>
              <p className="text-xs text-navy-900/50 mt-1">{a.detail}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ReportsPage(){
  const reports = [
    { name:"Daily Operations Summary — Aug 12, 2026", size:"212 KB", type:"PDF" },
    { name:"Weekly Recovery & Recycling Report — Week 32", size:"480 KB", type:"PDF" },
    { name:"Monthly CO₂ Impact Report — July 2026", size:"1.1 MB", type:"PDF" },
    { name:"Raw Detection Log Export — Last 7 Days", size:"3.4 MB", type:"CSV" },
  ];
  return (
    <div>
      <PageHeader eyebrow="Documentation" title="Reports" desc="Generated summaries for stakeholders, municipalities and partner organizations." right={<DemoBadge label="Demo — sample reports"/>} />
      <Card>
        <div className="divide-y divide-navy-900/5">
          {reports.map((r,i)=>(
            <div key={i} className="flex items-center justify-between py-3.5">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-navy-900/[0.04] flex items-center justify-center"><Icon name="file" className="w-4.5 h-4.5 text-navy-900/50"/></div>
                <div><div className="text-sm font-medium text-navy-900">{r.name}</div><div className="text-[11px] text-navy-900/40">{r.type} · {r.size}</div></div>
              </div>
              <button className="text-xs font-medium text-forest-700 border border-forest-700/30 rounded-lg px-3 py-1.5 hover:bg-forest-700/5 transition">Download</button>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function AboutPage(){
  const stack = [
    { name:"Computer Vision", desc:"Object detection & material classification" },
    { name:"Machine Learning", desc:"Continuous accuracy improvement from field data" },
    { name:"Robotics / Automation", desc:"Actuated sorting arms and diverter gates" },
    { name:"IoT Sensors", desc:"Weight, fill-level, vibration and verification sensors" },
    { name:"Solar Power", desc:"Off-grid capable, low operating cost" },
    { name:"Cloud Analytics", desc:"Fleet-wide dashboards and predictive alerts" },
  ];
  return (
    <div>
      <PageHeader eyebrow="Technology" title="About / Technology" desc="How EcoSort AI works, from mixed waste to recovered resource." right={<DemoBadge/>} />
      <Card title="End-to-End Workflow" className="mb-5">
        <div className="flex flex-wrap items-center gap-2">
          {["Mixed Waste","Camera + Sensors","AI Computer Vision","Material Classification","Sensor Verification","Decision Engine","Automated Sorting","Material Bins","Resource Recovery","Recycling Analytics"].map((s,i,arr)=>(
            <React.Fragment key={i}>
              <span className="text-xs font-medium bg-navy-900/[0.04] rounded-full px-3 py-1.5 text-navy-900/70">{s}</span>
              {i<arr.length-1 && <Icon name="arrowRight" className="w-3.5 h-3.5 text-navy-900/25"/>}
            </React.Fragment>
          ))}
        </div>
      </Card>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {stack.map((s,i)=>(
          <Card key={i}><h4 className="font-display font-semibold text-sm mb-1">{s.name}</h4><p className="text-xs text-navy-900/50">{s.desc}</p></Card>
        ))}
      </div>
    </div>
  );
}

function AdminPage(){
  const [apiMode,setApiMode]=useState("simulated");
  return (
    <div>
      <PageHeader eyebrow="Configuration" title="Admin / Settings" desc="Facility, integration and account configuration." right={<DemoBadge/>} />
      <div className="grid lg:grid-cols-2 gap-5">
        <Card title="AI Inference Source">
          <div className="space-y-2">
            {[["simulated","Simulated Demo Data","No external dependency — used for this hackathon build"],["yolo","YOLO Inference API","Connect a hosted YOLO endpoint"],["tflite","TensorFlow Lite (edge)","On-device inference on Raspberry Pi / Jetson"],["opencv","OpenCV Pipeline","Classical CV fallback pipeline"]].map(([k,l,d])=>(
              <label key={k} className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition ${apiMode===k?"border-forest-700 bg-forest-700/5":"border-navy-900/10"}`}>
                <input type="radio" name="api" className="mt-1 accent-forest-700" checked={apiMode===k} onChange={()=>setApiMode(k)}/>
                <div><div className="text-sm font-medium">{l}</div><div className="text-xs text-navy-900/45">{d}</div></div>
              </label>
            ))}
          </div>
        </Card>
        <Card title="Facility Details">
          <div className="space-y-3">
            {[["Facility Name","EcoSort AI — Demo Unit 01"],["Location","Coimbatore, Tamil Nadu"],["Machine ID","ES-AI-2026-001"],["Firmware","v0.9.2-hackathon"]].map(([l,v],i)=>(
              <div key={i}><label className="text-[11px] text-navy-900/40">{l}</label><input defaultValue={v} className="w-full mt-1 text-sm border border-navy-900/10 rounded-lg px-3 py-2 bg-navy-900/[0.02]"/></div>
            ))}
          </div>
        </Card>
      </div>
      <Card title="Future Integrations" className="mt-5">
        <div className="flex flex-wrap gap-2">
          {["Firebase","PostgreSQL","MongoDB","MQTT","ESP32","Raspberry Pi","YOLOv8","OpenCV"].map((t,i)=>(
            <span key={i} className="text-xs font-mono bg-navy-900/[0.04] rounded-lg px-3 py-1.5 text-navy-900/60">{t}</span>
          ))}
        </div>
      </Card>
    </div>
  );
}

/* ============================== SHELL: SIDEBAR + TOPBAR ============================== */
const NAV = [
  { id:"dashboard", label:"Command Center", icon:"grid" },
  { id:"detection", label:"AI Waste Detection", icon:"camera" },
  { id:"sorting", label:"Sorting Monitor", icon:"branch" },
  { id:"bins", label:"Smart Bins", icon:"trash" },
  { id:"recovery", label:"Resource Recovery", icon:"recycle" },
  { id:"analytics", label:"Analytics", icon:"chart" },
  { id:"recommendations", label:"AI Recommendations", icon:"brain" },
  { id:"twin", label:"Digital Twin", icon:"boxes" },
  { id:"simulator", label:"What-If Simulator", icon:"sliders" },
  { id:"alerts", label:"Alerts", icon:"bell" },
  { id:"reports", label:"Reports", icon:"file" },
  { id:"about", label:"About / Technology", icon:"info" },
  { id:"admin", label:"Admin / Settings", icon:"settings" },
];
const PAGES = {
  dashboard: DashboardHome, detection: AIDetectionPage, sorting: SortingMonitorPage, bins: SmartBinsPage,
  recovery: ResourceRecoveryPage, analytics: AnalyticsPage, recommendations: RecommendationsPage,
  twin: DigitalTwinPage, simulator: SimulatorPage, alerts: AlertsPage, reports: ReportsPage,
  about: AboutPage, admin: AdminPage,
};

function DashboardShell({ page, goto, goLanding }) {
  const [open,setOpen]=useState(false);
  const PageComp = PAGES[page] || DashboardHome;
  return (
    <div className="min-h-screen flex bg-sand-50">
      {/* Sidebar (desktop) */}
      <aside className="hidden lg:flex lg:flex-col w-64 shrink-0 bg-navy-950 text-white/80 sticky top-0 h-screen">
        <button onClick={goLanding} className="flex items-center gap-2 px-5 h-16 border-b border-white/5 text-left">
          <div className="w-8 h-8 rounded-lg bg-lime-500 flex items-center justify-center"><Icon name="recycle" className="w-4.5 h-4.5 text-navy-950"/></div>
          <span className="font-display font-semibold text-white text-sm">EcoSort <span className="text-lime-400">AI</span></span>
        </button>
        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-0.5">
          {NAV.map(n=>(
            <button key={n.id} onClick={()=>goto(n.id)} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition ${page===n.id?"bg-white/10 text-white":"hover:bg-white/5 text-white/55"}`}>
              <Icon name={n.icon} className="w-4.5 h-4.5"/>{n.label}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-white/5">
          <div className="flex items-center gap-2 text-[11px] text-lime-400"><span className="w-1.5 h-1.5 rounded-full bg-lime-400 pulse-dot"></span>Machine Online</div>
          <button onClick={()=>goto("pricing")} className="mt-3 w-full text-xs font-medium bg-lime-500 text-navy-950 rounded-lg py-2 hover:bg-lime-400 transition">Upgrade Plan</button>
        </div>
      </aside>

      {/* Mobile drawer */}
      {open && (
        <div className="lg:hidden fixed inset-0 z-40">
          <div className="absolute inset-0 bg-navy-950/60" onClick={()=>setOpen(false)}></div>
          <aside className="absolute left-0 top-0 h-full w-72 bg-navy-950 text-white/80 p-4">
            <div className="flex items-center justify-between mb-4">
              <span className="font-display font-semibold text-white text-sm">EcoSort <span className="text-lime-400">AI</span></span>
              <button onClick={()=>setOpen(false)}><Icon name="x" className="w-5 h-5"/></button>
            </div>
            <nav className="space-y-0.5">
              {NAV.map(n=>(
                <button key={n.id} onClick={()=>{goto(n.id); setOpen(false);}} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition ${page===n.id?"bg-white/10 text-white":"text-white/55"}`}>
                  <Icon name={n.icon} className="w-4.5 h-4.5"/>{n.label}
                </button>
              ))}
            </nav>
          </aside>
        </div>
      )}

      <div className="flex-1 min-w-0">
        <header className="h-16 flex items-center justify-between px-4 md:px-8 border-b border-navy-900/5 bg-sand-50/90 backdrop-blur sticky top-0 z-30">
          <div className="flex items-center gap-3">
            <button className="lg:hidden" onClick={()=>setOpen(true)}><Icon name="menu" className="w-5 h-5"/></button>
            <div className="text-sm text-navy-900/40">EcoSort AI / <span className="text-navy-900 font-medium">{NAV.find(n=>n.id===page)?.label || "Dashboard"}</span></div>
          </div>
          <div className="flex items-center gap-3">
            <span className="hidden sm:flex items-center gap-1.5 text-xs text-forest-700 bg-forest-700/10 rounded-full px-3 py-1.5"><Icon name="wifi" className="w-3.5 h-3.5"/>Connected</span>
            <div className="w-9 h-9 rounded-full bg-navy-900/10 flex items-center justify-center text-xs font-semibold text-navy-900/60">HK</div>
          </div>
        </header>
        <main className="p-4 md:p-8">
          <PageComp/>
        </main>
      </div>
    </div>
  );
}

/* ============================== MARKETING: LANDING ============================== */
function ConveyorHero(){
  return (
    <div className="relative rounded-3xl overflow-hidden bg-navy-950 p-6 md:p-8">
      <div className="grain absolute inset-0"></div>
      <div className="flex items-center justify-between text-white/50 text-[11px] font-mono mb-6">
        <span>LIVE FEED — DEMO UNIT 01</span>
        <span className="flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full bg-lime-400 pulse-dot"></span>SIMULATED</span>
      </div>
      <div className="relative h-40 md:h-48 rounded-xl overflow-hidden belt mb-6">
        {CATS.slice(0,6).map((c,i)=>(
          <div key={i} className="item-anim absolute top-1/2 -translate-y-1/2 w-9 h-9 md:w-10 md:h-10 rounded-md shadow-lg flex items-center justify-center text-[9px] font-mono text-white/90"
            style={{ background:c.color, animationDuration:`${7+i*0.6}s`, animationDelay:`${i*1.1}s` }}>{c.label.slice(0,2).toUpperCase()}</div>
        ))}
        <div className="absolute right-0 top-0 bottom-0 w-16 md:w-20 bg-gradient-to-l from-navy-950 to-transparent flex items-center justify-center">
          <Icon name="branch" className="w-6 h-6 text-lime-400"/>
        </div>
      </div>
      <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
        {CATS.map((c,i)=>(
          <div key={i} className="rounded-lg px-2 py-2 text-center" style={{background:`${c.color}22`, border:`1px solid ${c.color}55`}}>
            <div className="text-[10px] text-white/70 truncate">{c.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function LandingPage({ goto }){
  const problems = [
    { icon:"trash", title:"Mixed Waste", desc:"Recyclable materials become contaminated when disposed of together, lowering their recovery value." },
    { icon:"branch", title:"Manual Sorting", desc:"Sorting is labour-intensive, slow, and can expose workers to unsafe or unsanitary material." },
    { icon:"dollar", title:"Resource Loss", desc:"Recoverable materials are lost to landfill or sold at low-value disposal rates." },
    { icon:"chart", title:"Poor Visibility", desc:"Organizations lack real-time data about waste generation, sorting accuracy and recovery." },
  ];
  const flow = ["Mixed Waste","Camera + Sensors","AI Computer Vision","Material Classification","Sensor Verification","Decision Engine","Automated Sorting","Material-Specific Bins","Resource Recovery","Recycling Analytics"];
  return (
    <div className="bg-sand-50">
      {/* Nav */}
      <header className="sticky top-0 z-40 bg-sand-50/85 backdrop-blur border-b border-navy-900/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-forest-700 flex items-center justify-center"><Icon name="recycle" className="w-4.5 h-4.5 text-lime-400"/></div>
            <span className="font-display font-semibold text-navy-900">EcoSort <span className="text-forest-700">AI</span></span>
          </div>
          <nav className="hidden md:flex items-center gap-7 text-sm text-navy-900/60">
            <a href="#problem" className="hover:text-navy-900">Problem</a>
            <a href="#solution" className="hover:text-navy-900">Solution</a>
            <a href="#workflow" className="hover:text-navy-900">Technology</a>
            <button onClick={()=>goto("pricing")} className="hover:text-navy-900">Pricing</button>
          </nav>
          <button onClick={()=>goto("dashboard")} className="text-sm font-medium bg-forest-700 text-white rounded-xl px-4 py-2 hover:bg-forest-800 transition">Launch Live Demo</button>
        </div>
      </header>

      {/* Hero */}
      <section className="max-w-7xl mx-auto px-5 md:px-8 pt-14 md:pt-20 pb-16 grid lg:grid-cols-2 gap-10 items-center">
        <div>
          <div className="inline-flex items-center gap-2 text-[11px] font-medium bg-lime-500/15 text-forest-700 px-3 py-1.5 rounded-full mb-5">
            <Icon name="zap" className="w-3.5 h-3.5"/> National Hackathon 2026 — Live Prototype
          </div>
          <h1 className="font-display text-4xl md:text-5xl font-semibold leading-[1.08] text-navy-900">
            ECO SORT <span className="text-forest-700">AI</span>
          </h1>
          <p className="mt-4 text-lg text-navy-900/70 font-medium">AI-Powered Intelligent Waste Sorting, Recycling &amp; Resource Recovery System</p>
          <p className="mt-1 font-display text-forest-700 font-semibold">"See Waste. Sort Smart. Recover Value."</p>
          <p className="mt-4 text-sm md:text-base text-navy-900/55 leading-relaxed max-w-lg">An intelligent platform combining AI, computer vision, automation, IoT and renewable energy to transform waste segregation into measurable resource recovery.</p>
          <div className="flex flex-wrap gap-3 mt-7">
            <button onClick={()=>goto("dashboard")} className="bg-forest-700 hover:bg-forest-800 text-white text-sm font-medium px-5 py-3 rounded-xl transition flex items-center gap-2">Launch Live Demo <Icon name="arrowRight" className="w-4 h-4"/></button>
            <a href="#workflow" className="border border-navy-900/15 text-navy-900/70 text-sm font-medium px-5 py-3 rounded-xl hover:bg-navy-900/5 transition">Explore Technology</a>
          </div>
          <div className="flex flex-wrap gap-2 mt-8">
            {["AI Waste Detection","Automated Sorting","IoT Monitoring","Solar Powered","Resource Recovery"].map((b,i)=>(
              <span key={i} className="text-[11px] font-medium text-navy-900/55 bg-white border border-navy-900/10 rounded-full px-3 py-1.5">{b}</span>
            ))}
          </div>
        </div>
        <ConveyorHero/>
      </section>

      {/* Mini dashboard preview */}
      <section className="max-w-7xl mx-auto px-5 md:px-8 pb-16">
        <Card title="Live Dashboard Preview" subtitle="A glimpse of the EcoSort AI Command Center" right={<DemoBadge/>}>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <StatCard icon="layers" label="Waste Processed" value="1,284 kg" sub="+6.2%"/>
            <StatCard icon="trend" label="Recovery Rate" value="82.4%" tone="lime"/>
            <StatCard icon="shield" label="Sorting Accuracy" value="94.7%" tone="navy"/>
            <StatCard icon="leaf" label="CO₂ Avoided" value="642 kg"/>
          </div>
        </Card>
      </section>

      {/* Problem */}
      <section id="problem" className="max-w-7xl mx-auto px-5 md:px-8 py-16 border-t border-navy-900/5">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="text-[11px] uppercase tracking-widest text-forest-700 font-semibold mb-2">Why it matters</div>
          <h2 className="font-display text-2xl md:text-3xl font-semibold text-navy-900">The Problem We Solve</h2>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-10">
          {problems.map((p,i)=>(
            <Card key={i}>
              <div className="w-10 h-10 rounded-xl bg-forest-700/10 text-forest-700 flex items-center justify-center mb-3"><Icon name={p.icon} className="w-5 h-5"/></div>
              <h3 className="font-display font-semibold text-sm mb-1.5">{p.title}</h3>
              <p className="text-xs text-navy-900/50 leading-relaxed">{p.desc}</p>
            </Card>
          ))}
        </div>
        <div className="flex flex-wrap items-center justify-center gap-2">
          {["Mixed Waste","Poor Segregation","Recycling Loss","Higher Disposal Cost","Environmental Impact"].map((s,i,arr)=>(
            <React.Fragment key={i}>
              <span className="text-xs font-medium bg-white border border-navy-900/10 rounded-full px-3 py-1.5 text-navy-900/60">{s}</span>
              {i<arr.length-1 && <Icon name="arrowRight" className="w-3.5 h-3.5 text-navy-900/25"/>}
            </React.Fragment>
          ))}
        </div>
      </section>

      {/* Solution / workflow */}
      <section id="solution" className="bg-navy-950 py-16">
        <div id="workflow" className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <div className="text-[11px] uppercase tracking-widest text-lime-400 font-semibold mb-2">How it works</div>
            <h2 className="font-display text-2xl md:text-3xl font-semibold text-white">From Waste to Recoverable Resources</h2>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-2">
            {flow.map((s,i,arr)=>(
              <React.Fragment key={i}>
                <span className="text-xs font-medium bg-white/5 border border-white/10 text-white/75 rounded-full px-3.5 py-2">{s}</span>
                {i<arr.length-1 && <Icon name="arrowRight" className="w-3.5 h-3.5 text-lime-400/60"/>}
              </React.Fragment>
            ))}
          </div>
        </div>
      </section>

      {/* Tech pillars */}
      <section className="max-w-7xl mx-auto px-5 md:px-8 py-16">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="text-[11px] uppercase tracking-widest text-forest-700 font-semibold mb-2">Under the hood</div>
          <h2 className="font-display text-2xl md:text-3xl font-semibold text-navy-900">Built on a Serious Technology Stack</h2>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {[["camera","Computer Vision","Real-time object detection at the infeed point"],["brain","Machine Learning","Classification models improving from field data"],["branch","Robotic Sorting","Actuated arms route items to the correct bin"],["wifi","IoT Sensors","Fill-level, weight and verification telemetry"],["sun","Solar Powered","Designed for low-cost, off-grid deployment"],["globe","Cloud Analytics","Fleet dashboards across multiple sites"]].map((t,i)=>(
            <Card key={i}>
              <div className="w-10 h-10 rounded-xl bg-lime-500/15 text-forest-700 flex items-center justify-center mb-3"><Icon name={t[0]} className="w-5 h-5"/></div>
              <h3 className="font-display font-semibold text-sm mb-1.5">{t[1]}</h3>
              <p className="text-xs text-navy-900/50 leading-relaxed">{t[2]}</p>
            </Card>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-7xl mx-auto px-5 md:px-8 pb-20">
        <div className="rounded-3xl bg-forest-700 text-white p-10 md:p-14 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h3 className="font-display text-2xl font-semibold mb-2">Ready to see it in action?</h3>
            <p className="text-white/70 text-sm max-w-md">Explore the full command center, AI detection demo, and simulator — no signup required for the hackathon demo.</p>
          </div>
          <div className="flex gap-3 shrink-0">
            <button onClick={()=>goto("dashboard")} className="bg-lime-500 text-navy-950 text-sm font-semibold px-5 py-3 rounded-xl hover:bg-lime-400 transition">Launch Live Demo</button>
            <button onClick={()=>goto("pricing")} className="border border-white/25 text-white text-sm font-medium px-5 py-3 rounded-xl hover:bg-white/10 transition">View Plans</button>
          </div>
        </div>
      </section>

      <Footer goto={goto}/>
    </div>
  );
}

function Footer({ goto }){
  return (
    <footer className="border-t border-navy-900/5 py-10">
      <div className="max-w-7xl mx-auto px-5 md:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-forest-700 flex items-center justify-center"><Icon name="recycle" className="w-4 h-4 text-lime-400"/></div>
          <span className="font-display font-semibold text-sm text-navy-900">EcoSort AI</span>
        </div>
        <p className="text-xs text-navy-900/40 text-center">Built for a national-level hackathon demonstration. All data shown is simulated.</p>
        <div className="flex gap-4 text-xs text-navy-900/50">
          <button onClick={()=>goto("landing")} className="hover:text-navy-900">Home</button>
          <button onClick={()=>goto("pricing")} className="hover:text-navy-900">Pricing</button>
          <button onClick={()=>goto("about")} className="hover:text-navy-900">Technology</button>
        </div>
      </div>
    </footer>
  );
}

/* ============================== PRICING / DEMO SUBSCRIPTION ============================== */
function PricingPage({ goto }){
  const [billing,setBilling]=useState("monthly");
  const [modal,setModal]=useState(null);
  const plans = [
    { id:"starter", name:"Starter Demo", tagline:"For hackathon judges & quick evaluation", price:{monthly:0, annual:0}, cta:"Start Free Demo",
      features:["Full dashboard access (simulated data)","1 virtual sorting unit","AI detection demo (upload + camera sim)","Community support","Data resets every session"] },
    { id:"pro", name:"Professional", tagline:"For pilot deployments at a single facility", price:{monthly:4999, annual:3999}, highlight:true, cta:"Start Free Trial",
      features:["Everything in Starter","Up to 5 physical sorting units","Live IoT + camera integration","Real-time alerts & reports","Priority email support","API access for analytics"] },
    { id:"enterprise", name:"Enterprise", tagline:"For municipalities, smart cities & large MSMEs", price:{monthly:"Custom", annual:"Custom"}, cta:"Contact Sales",
      features:["Everything in Professional","Unlimited sorting units & sites","Custom AI model tuning","Dedicated onboarding & SLA","Multi-site fleet analytics","On-prem / private cloud option"] },
  ];
  return (
    <div className="bg-sand-50 min-h-screen">
      <header className="sticky top-0 z-40 bg-sand-50/85 backdrop-blur border-b border-navy-900/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 flex items-center justify-between">
          <button onClick={()=>goto("landing")} className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-forest-700 flex items-center justify-center"><Icon name="recycle" className="w-4.5 h-4.5 text-lime-400"/></div>
            <span className="font-display font-semibold text-navy-900">EcoSort <span className="text-forest-700">AI</span></span>
          </button>
          <button onClick={()=>goto("dashboard")} className="text-sm font-medium bg-forest-700 text-white rounded-xl px-4 py-2 hover:bg-forest-800 transition">Launch Live Demo</button>
        </div>
      </header>

      <section className="max-w-5xl mx-auto px-5 md:px-8 pt-14 pb-6 text-center">
        <div className="text-[11px] uppercase tracking-widest text-forest-700 font-semibold mb-2">Plans</div>
        <h1 className="font-display text-3xl md:text-4xl font-semibold text-navy-900">Simple plans for every stage of deployment</h1>
        <p className="text-sm text-navy-900/50 mt-3 max-w-xl mx-auto">Start with a free interactive demo — no card required. This is a hackathon prototype; no real payments are processed.</p>
        <div className="inline-flex items-center gap-1 bg-white border border-navy-900/10 rounded-full p-1 mt-6">
          <button onClick={()=>setBilling("monthly")} className={`text-xs font-medium px-4 py-1.5 rounded-full transition ${billing==="monthly"?"bg-forest-700 text-white":"text-navy-900/50"}`}>Monthly</button>
          <button onClick={()=>setBilling("annual")} className={`text-xs font-medium px-4 py-1.5 rounded-full transition ${billing==="annual"?"bg-forest-700 text-white":"text-navy-900/50"}`}>Annual <span className="text-lime-600">· save 20%</span></button>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-5 md:px-8 pb-20 grid md:grid-cols-3 gap-6">
        {plans.map(p=>(
          <div key={p.id} className={`rounded-2xl p-6 flex flex-col ${p.highlight ? "bg-navy-950 text-white ring-2 ring-lime-500 relative" : "bg-white border border-navy-900/10 text-navy-900"}`}>
            {p.highlight && <span className="absolute -top-3 left-6 text-[10px] font-semibold bg-lime-500 text-navy-950 px-2.5 py-1 rounded-full">MOST POPULAR</span>}
            <h3 className="font-display font-semibold text-lg">{p.name}</h3>
            <p className={`text-xs mt-1 ${p.highlight?"text-white/55":"text-navy-900/50"}`}>{p.tagline}</p>
            <div className="mt-5 mb-1">
              {typeof p.price[billing]==="number" ? (
                <span className="font-display text-3xl font-semibold">{p.price[billing]===0 ? "Free" : `₹${p.price[billing].toLocaleString("en-IN")}`}</span>
              ) : <span className="font-display text-3xl font-semibold">{p.price[billing]}</span>}
              {typeof p.price[billing]==="number" && p.price[billing]>0 && <span className={`text-xs ${p.highlight?"text-white/45":"text-navy-900/40"}`}> /month</span>}
            </div>
            <ul className="space-y-2.5 my-5 flex-1">
              {p.features.map((f,i)=>(
                <li key={i} className="flex items-start gap-2 text-sm">
                  <Icon name="check" className={`w-4 h-4 mt-0.5 shrink-0 ${p.highlight?"text-lime-400":"text-forest-700"}`}/>
                  <span className={p.highlight?"text-white/80":"text-navy-900/70"}>{f}</span>
                </li>
              ))}
            </ul>
            <button onClick={()=>setModal(p)} className={`text-sm font-semibold rounded-xl py-2.5 transition ${p.highlight ? "bg-lime-500 text-navy-950 hover:bg-lime-400" : "bg-forest-700 text-white hover:bg-forest-800"}`}>{p.cta}</button>
          </div>
        ))}
      </section>

      {modal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-5">
          <div className="absolute inset-0 bg-navy-950/60" onClick={()=>setModal(null)}></div>
          <div className="relative bg-white rounded-2xl p-6 max-w-sm w-full fade-up">
            <div className="w-11 h-11 rounded-xl bg-lime-500/15 text-forest-700 flex items-center justify-center mb-4"><Icon name="check" className="w-5 h-5"/></div>
            <h3 className="font-display font-semibold text-lg mb-1">{modal.name} selected</h3>
            <p className="text-sm text-navy-900/55 mb-4">This is a demo subscription flow built for the hackathon — no payment is processed and no real account is created. In production this would connect to a billing provider (e.g. Razorpay / Stripe).</p>
            <div className="flex gap-2">
              <button onClick={()=>{ setModal(null); goto("dashboard"); }} className="flex-1 bg-forest-700 text-white text-sm font-medium rounded-xl py-2.5 hover:bg-forest-800 transition">Continue to Demo</button>
              <button onClick={()=>setModal(null)} className="px-4 text-sm font-medium text-navy-900/50 hover:text-navy-900">Cancel</button>
            </div>
          </div>
        </div>
      )}

      <Footer goto={goto}/>
    </div>
  );
}

/* ============================== APP ROOT ============================== */
function App(){
  const [page,setPage]=useState("landing");
  const goto = (p) => { setPage(p); window.scrollTo({top:0, behavior:"instant"}); };

  if (page === "landing") return <LandingPage goto={goto}/>;
  if (page === "pricing") return <PricingPage goto={goto}/>;
  return <DashboardShell page={page} goto={goto} goLanding={()=>goto("landing")}/>;
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
