# EcoSort AI 🌱
**AI-Powered Intelligent Waste Sorting, Recycling & Resource Recovery System**
*"See Waste. Sort Smart. Recover Value."*

A complete, judge-ready web demo built for a national-level hackathon. Everything runs from a **single `index.html` file** — no build step, no npm install, no backend required — so it deploys instantly and never breaks on stage.

## What's inside

- **Landing page** — hero, problem section, solution/workflow, tech pillars, CTA
- **Dashboard (Command Center)** — 8 live stat cards + 5 charts (Recharts)
- **AI Waste Detection** — simulated upload / camera inference with confidence scores
- **Sorting Monitor** — animated conveyor + pipeline stage tracker + arm diagnostics
- **Smart Bins** — fill-level gauges per material category
- **Resource Recovery** — recovered value by material (₹)
- **Analytics** — radar chart, throughput vs recovery, contamination breakdown
- **AI Recommendations** — model-style operational suggestions
- **Digital Factory / Digital Twin** — conceptual live facility map
- **What-If Simulator** — interactive sliders projecting recovery/accuracy/cost
- **Alerts**, **Reports**, **About/Technology**, **Admin/Settings**
- **Pricing page with a demo subscription model** (Starter / Professional / Enterprise, monthly-annual toggle, plan-selection modal that's clearly labeled as non-billing)

All data is clearly labeled **"Demo Mode — Simulated Data"**. Nothing here claims to be verified real-world performance.

## Tech approach

Built with **React 18 + Recharts + Tailwind CSS**, loaded via CDN with in-browser Babel — so it's real React code (easy to later migrate into a Vite project) but requires zero tooling to run or host. Fonts: Space Grotesk (display) + Inter (body) + JetBrains Mono (data).

## Run it locally

Just open `index.html` in a browser. For a local server (recommended, some browsers restrict CDN scripts on `file://`):

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Deploy to GitHub Pages (2 minutes)

1. Create a new repo on GitHub (e.g. `ecosort-ai`).
2. Push this project:
   ```bash
   git init
   git add .
   git commit -m "EcoSort AI hackathon demo"
   git branch -M main
   git remote add origin https://github.com/<your-username>/ecosort-ai.git
   git push -u origin main
   ```
3. On GitHub: **Settings → Pages → Source → Deploy from branch → `main` / `root`** → Save.
4. Your site goes live at `https://<your-username>.github.io/ecosort-ai/` within a minute.

> I can't push to your GitHub for you directly (I don't have network access or your credentials in this environment) — but the steps above are all you need, and the site needs zero build config since it's a single static HTML file.

## Roadmap to a production build (for judges' Q&A)

This demo is intentionally framed as a working prototype with a phased path to production:

- **Frontend:** migrate to Vite + TypeScript + React Router, keep the same component structure
- **AI:** swap the simulated detection in `AIDetectionPage` for a real YOLOv8 / TFLite / OpenCV inference endpoint (interface already isolated in one function, see `runDetection`)
- **IoT:** connect bin fill-level and sensor data via MQTT from ESP32 / Raspberry Pi controllers
- **Backend/data:** Node.js + Express or FastAPI with PostgreSQL/MongoDB, replacing the mock arrays at the top of the script
- **Billing:** connect the pricing page's "Start Free Trial" / "Contact Sales" flow to Razorpay or Stripe for real subscriptions

## File structure

```
ecosort/
├── index.html          ← page shell: loads CDN libraries + links the files below
├── styles.css           ← custom CSS (conveyor belt animation, scrollbar, fade/pulse effects)
├── tailwind.config.js   ← Tailwind theme (forest/navy/lime palette, Space Grotesk/Inter/JetBrains Mono)
├── app.js               ← the entire React app: all icons, mock data, and 15 pages (landing, 13 dashboard pages, pricing)
└── README.md            ← this file
```

`app.js` is JSX, compiled in the browser by Babel Standalone (loaded via CDN in `index.html`) — no build step needed. Keep all four files in the same folder; `index.html` references the other three by relative path.
